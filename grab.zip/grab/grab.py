import cv2
import os
import glob

ext = ['png', 'jpg']
training = '/06/training'
print(os.listdir(training))

for i, filename in enumerate(os.listdir(training)):
    image_training = cv2.imread(training + '/' + filename)

testing = '/06/testing'
print(os.listdir(testing))

for i, filename in enumerate(os.listdir(testing)):
    image_testing = cv2.imread(testing + '/' + filename)

# detect feature
surf = cv2.xfeatures2d.SURF_create()

# keypoint (untuk mengetahui titik yang penting)
# descriptor (untuk mengetahui mengapa titik tersebut penting)
kp_training , desc_training = surf.detectAndCompute(image_training , None)
kp_testing , desc_testing = surf.detectAndCompute(image_testing , None)

# astype --> meningkatkan tingkat akurasi dengan merubah ke float
desc_training = desc_training.astype('f')
desc_testing = desc_testing.astype('f')

# Flann --> algo untuk detect keypoint yang sama
# jika algo = 0 maka kdtree
# k = 2 artinya mencari 2 titik terdekat
flann = cv2.FlannBasedMatcher(dict(algorithm = 0))
matches = flann.knnMatch(desc_training,desc_testing,k=2)

# valid_match --> untuk menentukan diantara yg match mana yang valid
valid_match = []
for i in range(len(matches)):
    valid_match.append([0,0])


for i,(m,n) in enumerate(matches):
    if(m.distance < 0.7 * n.distance):
        # valid
        valid_match[i] = [1,0]

img_result = cv2.drawMatchesKnn(image_training,kp_training,image_testing,kp_testing,matches,None,matchesMask = valid_match)

cv2.imshow('Image',img_result)
cv2.waitKey(0)


